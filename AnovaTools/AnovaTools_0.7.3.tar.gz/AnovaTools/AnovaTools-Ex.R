pkgname <- "AnovaTools"
source(file.path(R.home("share"), "R", "examples-header.R"))
options(warn = 1)
library('AnovaTools')

base::assign(".oldSearch", base::search(), pos = 'CheckExEnv')
cleanEx()
nameEx("AnovaTools-package")
### * AnovaTools-package

flush(stderr()); flush(stdout())

### Name: AnovaTools-package
### Title: Anàlisi de la Variància amb models de dos i tres factors
###   aleatoris o mixtos
### Aliases: AnovaTools-package AnovaTools
### Keywords: package

### ** Examples

# anova2cross(aovObj, random = NULL, restricted = TRUE)
# anova2nest(aovObj, random = NULL)
# anova3nest(aovObj, random = NULL)



cleanEx()
nameEx("anova2cross")
### * anova2cross

flush(stderr()); flush(stdout())

### Name: anova2cross
### Title: Anàlisi de la Variància amb models de dos factors creuats
###   aleatoris o mixtos
### Aliases: anova2cross
### Keywords: models

### ** Examples

## Del llibre de Cuadras pàg. 296 exercici 11.2

temps <- c(548,519,637,619,776,818,641,678,701,
           846,858,855,517,493,618,876,741,849,
           602,719,731,628,595,687)
home <- gl(8, 3)
tractament <- gl(3, 1, length=24, labels=LETTERS[1:3])

fix.aov <- aov(temps ~ tractament + home)

(ac <- anova2cross(fix.aov, random="home"))

# Components de la variància
mm <- matrix(c(1,1,ac["tractament","Df"]+1,0), ncol=2)
solve(mm,ac[-1,"Mean Sq"])



cleanEx()
nameEx("anova2nest")
### * anova2nest

flush(stderr()); flush(stdout())

### Name: anova2nest
### Title: Anàlisi de la Variància amb models de dos factors jerarquitzats
###   aleatoris o mixtos
### Aliases: anova2nest
### Keywords: models

### ** Examples

qualitat <- c(6,6.3,6.1,6.7,5,5.3,5.7,5.5,6,6.1,6.7,6.2,4.9,5.5,5.2,5.1)
maquina <- gl(4,4)
operari <- gl(2,8,labels=c("A","B"))

fix.aov <- aov(qualitat ~ operari + maquina %in% operari)
anova(fix.aov)

anova2nest(fix.aov, random = "maquina")



cleanEx()
nameEx("anova3nest")
### * anova3nest

flush(stderr()); flush(stdout())

### Name: anova3nest
### Title: Anàlisi de la Variància amb models de tres factors jerarquitzats
###   aleatoris o mixtos
### Aliases: anova3nest
### Keywords: models

### ** Examples

# Exemple dels "bessons"
CAnaerobia <- c(20.6, 20.62, 20.3, 20.7, 22.1, 22.4, 22.3, 23, 21.4, 23.4, 
              24, 23.2, 24, 23.1, 23.5, 22, 21.6, 22.62, 20.5, 21.7, 22.2, 
              24.4, 23.3, 25, 24.4, 22.4, 21, 21.2, 20, 21.1, 22.1, 22)
zigosi <- gl(2,16,labels=c("mono","di"))
parella <- gl(4,4,length=32)
individu <- gl(2,2,length=32)
# La forma més explícita d'indicar el model lineal en el qual
# "parella" és jeràrquicament dins "zigosi" i "individu" és dins les 
# combinacions de "zigosi" i "parella" és:
bessons.aov <- aov(CAnaerobia ~ zigosi + parella %in% zigosi 
                      + individu %in% (parella %in% zigosi))

# Forma equivalent, més concisa
# bessons.aov <- aov(CAnaerobia ~ zigosi/parella/individu)

anova(bessons.aov)
# La taula ANOVA anterior no és correcta.

# La taula ANOVA correcta donat que el primer factor és fix i els dos darrers
# factors són aleatoris és:
anova3nest(bessons.aov, random = c("parella", "individu"))

# Equivalent a:
anova3nest(bessons.aov, random = c("individu", "parella"))
# l'ordre en el qual enumerem els factors aleatoris no importa

# També equivalent a:
anova3nest(bessons.aov, random = "parella")
# tots els jeràrquicament inferiors d'un aleatori els considera aleatoris



### * <FOOTER>
###
options(digits = 7L)
base::cat("Time elapsed: ", proc.time() - base::get("ptime", pos = 'CheckExEnv'),"\n")
grDevices::dev.off()
###
### Local variables: ***
### mode: outline-minor ***
### outline-regexp: "\\(> \\)?### [*]+" ***
### End: ***
quit('no')
